/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const format: (a: number, b: number, c: number, d: number) => [number, number];
export const get_config: (a: number, b: number) => [number, number];
export const get_dmmf: (a: number, b: number) => [number, number, number, number];
export const get_datamodel: (a: number, b: number) => [number, number, number, number];
export const lint: (a: number, b: number) => [number, number];
export const validate: (a: number, b: number) => [number, number];
export const merge_schemas: (a: number, b: number) => [number, number, number, number];
export const native_types: (a: number, b: number) => [number, number];
export const referential_actions: (a: number, b: number) => [number, number];
export const preview_features: () => [number, number];
export const text_document_completion: (a: number, b: number, c: number, d: number) => [number, number];
export const code_actions: (a: number, b: number, c: number, d: number) => [number, number];
export const references: (a: number, b: number, c: number, d: number) => [number, number];
export const hover: (a: number, b: number, c: number, d: number) => [number, number];
export const debug_panic: () => void;
export const __wbindgen_export_0: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
