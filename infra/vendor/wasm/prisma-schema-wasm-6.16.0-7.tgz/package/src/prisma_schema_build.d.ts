/* tslint:disable */
/* eslint-disable */
export function format(schema: string, params: string): string;
/**
 * Docs: https://prisma.github.io/prisma-engines/doc/prisma_fmt/fn.get_config.html
 */
export function get_config(params: string): string;
/**
 * Docs: https://prisma.github.io/prisma-engines/doc/prisma_fmt/fn.get_dmmf.html
 */
export function get_dmmf(params: string): string;
export function get_datamodel(params: string): string;
export function lint(input: string): string;
export function validate(params: string): void;
export function merge_schemas(input: string): string;
export function native_types(input: string): string;
export function referential_actions(input: string): string;
export function preview_features(): string;
/**
 * The API is modelled on an LSP [completion
 * request](https://github.com/microsoft/language-server-protocol/blob/gh-pages/_specifications/specification-3-16.md#completion-request-leftwards_arrow_with_hook).
 * Input and output are both JSON, the request being a `CompletionParams` object and the response
 * being a `CompletionList` object.
 */
export function text_document_completion(schema_files: string, params: string): string;
/**
 * This API is modelled on an LSP [code action
 * request](https://github.com/microsoft/language-server-protocol/blob/gh-pages/_specifications/specification-3-16.md#code-action-request-leftwards_arrow_with_hook).
 * Input and output are both JSON, the request being a
 * `CodeActionParams` object and the response being a list of
 * `CodeActionOrCommand` objects.
 */
export function code_actions(schema: string, params: string): string;
/**
 * This API is modelled on an LSP [references
 * request](https://github.com/microsoft/language-server-protocol/blob/gh-pages/_specifications/specification-3-16.md#find-references-request-leftwards_arrow_with_hook).
 * Input and output are both JSON, the request being a
 * `CodeActionParams` object and the response being a list of
 * `CodeActionOrCommand` objects.
 */
export function references(schema: string, params: string): string;
/**
 * This api is modelled on an LSP [hover request](https://github.com/microsoft/language-server-protocol/blob/gh-pages/_specifications/specification-3-16.md#hover-request-leftwards_arrow_with_hook).
 * Input and output are both JSON, the request being a `HoverParams` object
 * and the response being a `Hover` object.
 */
export function hover(schema_files: string, params: string): string;
/**
 * Trigger a panic inside the wasm module. This is only useful in development for testing panic
 * handling.
 */
export function debug_panic(): void;
