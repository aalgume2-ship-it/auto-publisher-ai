/* tslint:disable */
/* eslint-disable */
/**
 * The version of the @prisma/schema-engine-wasm.
 */
export function version(): string;
/**
 * Parameters defining the construction of an engine.
 */
export interface ConstructorOptions {
    /**
     * The initial datamodels to use.
     */
    datamodels: [string, string][] | undefined;
}

export interface TransactionOptions {
    /**
     * Whether or not to run a phantom query (i.e., a query that only influences Prisma event logs, but not the database itself)
     * before opening a transaction, committing, or rollbacking.
     */
    usePhantomQuery: boolean;
}

/**
 * Response result for the `schemaPush` method.
 */
export interface SchemaPushOutput {
    /**
     * How many migration steps were executed.
     */
    executedSteps: number;
    /**
     * Steps that cannot be executed in the current state of the database.
     */
    unexecutable: string[];
    /**
     * Destructive change warnings.
     */
    warnings: string[];
}

/**
 * Request params for the `schemaPush` method.
 */
export interface SchemaPushInput {
    /**
     * Push the schema ignoring destructive change warnings.
     */
    force: boolean;
    /**
     * The Prisma schema files.
     */
    schema: SchemasContainer;
    /**
     * The schema filter to use during the push.
     */
    filters: SchemaFilter;
}

/**
 * The output of the `reset` command.
 */
export interface ResetOutput {}

/**
 * The input to the `reset` command.
 */
export interface ResetInput {
    /**
     * The schema filter to use during the reset. Only relevant during \"soft\" resets though - usually we try to drop the whole database.
     */
    filter: SchemaFilter;
}

/**
 * The output of the `markMigrationRolledBack` command.
 */
export interface MarkMigrationRolledBackOutput {}

/**
 * Mark an existing failed migration as rolled back in the migrations table. It
 * will still be there, but ignored for all purposes except as audit trail.
 */
export interface MarkMigrationRolledBackInput {
    /**
     * The name of the migration to mark rolled back.
     */
    migrationName: string;
}

/**
 * The output of the `markMigrationApplied` command.
 */
export interface MarkMigrationAppliedOutput {}

/**
 * Mark a migration as applied in the migrations table.
 *
 * There are two possible outcomes:
 *
 * - The migration is already in the table, but in a failed state. In this case, we will mark it
 *   as rolled back, then create a new entry.
 * - The migration is not in the table. We will create a new entry in the migrations table. The
 *   `started_at` and `finished_at` will be the same.
 * - If it is already applied, we return a user-facing error.
 */
export interface MarkMigrationAppliedInput {
    /**
     * The name of the migration to mark applied.
     */
    migrationName: string;
    /**
     * The list of migrations, already loaded from disk.
     */
    migrationsList: MigrationList;
}

/**
 * Result type for the ensureConnectionValidity method.
 */
export interface EnsureConnectionValidityResult {}

/**
 * Make sure the schema engine can connect to the database from the Prisma schema.
 */
export interface EnsureConnectionValidityParams {
    /**
     * The datasource parameter.
     */
    datasource: DatasourceParam;
}

/**
 * A data loss warning or an unexecutable migration error, associated with the step that triggered it.
 */
export interface MigrationFeedback {
    /**
     * The human-readable message.
     */
    message: string;
    /**
     * The index of the step this pertains to.
     */
    stepIndex: number;
}

/**
 * The output of the `evaluateDataLoss` command.
 */
export interface EvaluateDataLossOutput {
    /**
     * The number migration steps that would be generated. If this is empty, we
     * wouldn\'t generate a new migration, unless the `draft` option is
     * passed.
     */
    migrationSteps: number;
    /**
     * Steps that cannot be executed on the local database in the
     * migration that would be generated.
     */
    unexecutableSteps: MigrationFeedback[];
    /**
     * Destructive change warnings for the local database. These are the
     * warnings *for the migration that would be generated*. This does not
     * include other potentially yet unapplied migrations.
     */
    warnings: MigrationFeedback[];
}

/**
 * Development command for migrations. Evaluate the data loss induced by the next
 * migration the engine would generate on the main database.
 *
 * At this stage, the engine does not create or mutate anything in the database
 * nor in the migrations directory.
 *
 * This is part of the `migrate dev` flow.
 *
 * **Note**: the engine currently assumes the main database schema is up-to-date
 * with the migration history.
 */
export interface EvaluateDataLossInput {
    /**
     * The list of migrations, already loaded from disk.
     */
    migrationsList: MigrationList;
    /**
     * The prisma schema files to migrate to.
     */
    schema: SchemasContainer;
    /**
     * Entities to be included or excluded during the data loss evaluation.
     */
    filters: SchemaFilter;
}

/**
 * Get the database version for error reporting.
 * @deprecated
 */
export interface GetDatabaseVersionInput {
    /**
     * The datasource parameter.
     */
    datasource: DatasourceParam;
}

/**
 * Information about a database view.
 */
export interface IntrospectionView {
    /**
     * The view definition.
     */
    definition: string;
    /**
     * The view name.
     */
    name: string;
    /**
     * The schema name.
     */
    schema: string;
}

/**
 * Result type for the introspect method.
 */
export interface IntrospectResult {
    /**
     * The introspected schema.
     */
    schema: SchemasContainer;
    /**
     * Optional views.
     */
    views: IntrospectionView[] | null;
    /**
     * Optional warnings.
     */
    warnings: string | null;
}

/**
 * Introspect the database (db pull)
 */
export interface IntrospectParams {
    /**
     * Prisma schema files.
     */
    schema: SchemasContainer;
    /**
     * Base directory path.
     */
    baseDirectoryPath: string;
    /**
     * Force flag.
     */
    force: boolean;
    /**
     * Composite type depth.
     */
    compositeTypeDepth: number;
    /**
     * Optional namespaces.
     */
    namespaces: string[] | null;
}

/**
 * Information about a SQL query result column.
 */
export interface SqlQueryColumnOutput {
    /**
     * Column name.
     */
    name: string;
    /**
     * Column type.
     */
    typ: string;
    /**
     * Whether the column is nullable.
     */
    nullable: boolean;
}

/**
 * Information about a SQL query parameter.
 */
export interface SqlQueryParameterOutput {
    /**
     * Parameter name.
     */
    name: string;
    /**
     * Parameter type.
     */
    typ: string;
    /**
     * Optional documentation.
     */
    documentation: string | null;
    /**
     * Whether the parameter is nullable.
     */
    nullable: boolean;
}

/**
 * Output for a single SQL query.
 */
export interface SqlQueryOutput {
    /**
     * The name of the query.
     */
    name: string;
    /**
     * The source SQL.
     */
    source: string;
    /**
     * Optional documentation.
     */
    documentation: string | null;
    /**
     * Query parameters.
     */
    parameters: SqlQueryParameterOutput[];
    /**
     * Query result columns.
     */
    resultColumns: SqlQueryColumnOutput[];
}

/**
 * Input for a single SQL query.
 */
export interface SqlQueryInput {
    /**
     * The name of the query.
     */
    name: string;
    /**
     * The source SQL.
     */
    source: string;
}

/**
 * Result type for the introspectSql method.
 */
export interface IntrospectSqlResult {
    /**
     * The introspected queries.
     */
    queries: SqlQueryOutput[];
}

/**
 * Params type for the introspectSql method.
 */
export interface IntrospectSqlParams {
    /**
     * The database URL.
     */
    url: string;
    /**
     * SQL queries to introspect.
     */
    queries: SqlQueryInput[];
}

/**
 * The result type for the `diff` method.
 */
export interface DiffResult {
    /**
     * The exit code that the CLI should return.
     */
    exitCode: number;
    /**
     * The diff script, if `script` was set to true in [`DiffParams`](DiffParams),
     * or a human-readable migration summary otherwise.
     * This is meant to be printed to the stdout by the caller.
     * Note: in `schema-engine-cli`, this is None.
     */
    stdout: string | null;
}

/**
 * The type of params for the `diff` method.
 */
export interface DiffParams {
    /**
     * The source of the schema to consider as a _starting point_.
     */
    from: DiffTarget;
    /**
     * The source of the schema to consider as a _destination_, or the desired
     * end-state.
     */
    to: DiffTarget;
    /**
     * The URL to a live database to use as a shadow database. The schema and data on
     * that database will be wiped during diffing.
     *
     * This is only necessary when one of `from` or `to` is referencing a migrations
     * directory as a source for the schema.
     * @deprecated.
     */
    shadowDatabaseUrl: string | null;
    /**
     * By default, the response will contain a human-readable diff. If you want an
     * executable script, pass the `\"script\": true` param.
     */
    script: boolean;
    /**
     * Whether the --exit-code param was passed.
     *
     * If this is set, the engine will return exitCode = 2 in the diffResult in case the diff is
     * non-empty. Other than this, it does not change the behaviour of the command.
     */
    exitCode: boolean | null;
    /**
     * The schema filter to use during the diff.
     */
    filters: SchemaFilter;
}

/**
 * The result type for `diagnoseMigrationHistory` responses.
 */
export interface DiagnoseMigrationHistoryOutput {
    /**
     * The names of the migrations for which the checksum of the script in the
     * migration directory does not match the checksum of the applied migration
     * in the database.
     */
    editedMigrationNames: string[];
    /**
     * The names of the migrations that are currently in a failed state in the migrations table.
     */
    failedMigrationNames: string[];
    /**
     * Is the migrations table initialized/present in the database?
     */
    hasMigrationsTable: boolean;
    /**
     * The current status of the migration history of the database
     * relative to migrations directory. `null` if they are in sync and up
     * to date.
     */
    history: HistoryDiagnostic | null;
}

/**
 * The request params for the `diagnoseMigrationHistory` method.
 */
export interface DiagnoseMigrationHistoryInput {
    /**
     * The list of migrations, already loaded from disk.
     */
    migrationsList: MigrationList;
    /**
     * Whether creating a shadow database is allowed.
     */
    optInToShadowDatabase: boolean;
    /**
     * The schema filter to use during checks on the database.
     * Note: Only used if opt_in_to_shadow_database is true.
     */
    filters: SchemaFilter;
}

/**
 * The response type for `devDiagnostic`.
 */
export interface DevDiagnosticOutput {
    /**
     * The suggested course of action for the CLI.
     */
    action: DevAction;
}

/**
 * The request type for `devDiagnostic`.
 */
export interface DevDiagnosticInput {
    /**
     * The list of migrations, already loaded from disk.
     */
    migrationsList: MigrationList;
    /**
     * The schema filter to use during checks on the database.
     */
    filters: SchemaFilter;
}

/**
 * Response for debug panic.
 */
export interface DebugPanicOutput {}

/**
 * Request for debug panic.
 */
export interface DebugPanicInput {}

/**
 * The type of results returned by dbExecute.
 */
export interface DbExecuteResult {}

/**
 * The type of params accepted by dbExecute.
 */
export interface DbExecuteParams {
    /**
     * The location of the live database to connect to.
     */
    datasourceType: DbExecuteDatasourceType;
    /**
     * The input script.
     */
    script: string;
}

/**
 * The output of the `createMigration` command.
 */
export interface CreateMigrationOutput {
    /**
     * The active connector type used.
     */
    connectorType: 'sqlite' | 'postgresql' | 'cockroachdb';
    /**
     * The generated name of migration directory, which the caller must use to create the new directory.
     */
    generatedMigrationName: string;
    /**
     * The migration script that was generated, if any.
     * It will be null if:
     * 1. The migration we generate would be empty, **AND**
     * 2. the `draft` param was not true, because in that case the engine would still generate an empty
     *    migration script.
     */
    migrationScript: string | null;
    /**
     * The file extension for generated migration files.
     */
    extension: string;
}

/**
 * The input to the `createMigration` command.
 */
export interface CreateMigrationInput {
    /**
     * If true, always generate a migration, but do not apply.
     */
    draft: boolean;
    /**
     * The user-given name for the migration. This will be used for the migration directory.
     */
    migrationName: string;
    /**
     * The list of migrations, already loaded from disk.
     */
    migrationsList: MigrationList;
    /**
     * The Prisma schema content to use as a target for the generated migration.
     */
    schema: SchemasContainer;
    /**
     * Entities to be included or excluded from the migration.
     */
    filters: SchemaFilter;
}

/**
 * The result for the `createDatabase` method.
 */
export interface CreateDatabaseResult {
    /**
     * The name of the created database.
     */
    databaseName: string;
}

/**
 * The type of params for the `createDatabase` method.
 */
export interface CreateDatabaseParams {
    /**
     * The datasource parameter.
     */
    datasource: DatasourceParam;
}

/**
 * The output of the `applyMigrations` command.
 */
export interface ApplyMigrationsOutput {
    /**
     * The names of the migrations that were just applied. Empty if no migration was applied.
     */
    appliedMigrationNames: string[];
}

/**
 * The input to the `applyMigrations` command.
 */
export interface ApplyMigrationsInput {
    /**
     * The list of migrations, already loaded from disk.
     */
    migrationsList: MigrationList;
    /**
     * The schema filter to use during the apply migrations.
     */
    filters: SchemaFilter;
}

/**
 * Reset action fields.
 */
export interface DevActionReset {
    /**
     * Why do we need to reset?
     */
    reason: string;
}

/**
 * A suggested action for the CLI `migrate dev` command.
 */
export type DevAction = ({ tag: "reset" } & DevActionReset) | { tag: "createMigration" };

/**
 * The location of the live database to connect to.
 */
export type DbExecuteDatasourceType = ({ tag: "schema" } & SchemasWithConfigDir) | ({ tag: "url" } & UrlContainer);

/**
 * Fields for the DatabaseIsBehind variant.
 */
export interface DatabaseIsBehindFields {}

/**
 * A diagnostic returned by `diagnoseMigrationHistory` when looking at the
 * database migration history in relation to the migrations directory.
 */
export type HistoryDiagnostic = { diagnostic: "databaseIsBehind"; unappliedMigrationNames: string[] } | { diagnostic: "migrationsDirectoryIsBehind"; unpersistedMigrationNames: string[] } | { diagnostic: "historiesDiverge"; lastCommonMigrationName: string | null; unpersistedMigrationNames: string[]; unappliedMigrationNames: string[] };

/**
 * A supported source for a database schema to diff in the `diff` command.
 */
export type DiffTarget = { tag: "empty" } | ({ tag: "schemaDatasource" } & SchemasWithConfigDir) | ({ tag: "schemaDatamodel" } & SchemasContainer) | ({ tag: "url" } & UrlContainer) | ({ tag: "migrations" } & MigrationList);

/**
 * The path to a live database taken as input. For flexibility, this can be Prisma schemas as strings, or only the
 * connection string. See variants.
 */
export type DatasourceParam = ({ tag: "Schema" } & SchemasContainer) | ({ tag: "ConnectionString" } & UrlContainer);

/**
 * Configuration of entities in the schema/database to be included or excluded from an operation.
 */
export interface SchemaFilter {
    /**
     * Tables that shall be considered \'externally\" managed. As per prisma.config.ts > tables.external.
     */
    externalTables: string[];
    /**
     * Enums that shall be considered \"externally\" managed. As per prisma.config.ts > enums.external.
     */
    externalEnums: string[];
}

/**
 * A list of Prisma schema files with a config directory.
 */
export interface SchemasWithConfigDir {
    /**
     * A list of Prisma schema files.
     */
    files: SchemaContainer[];
    /**
     * An optional directory containing the config files such as SSL certificates.
     */
    configDir: string;
}

/**
 * A container that holds multiple Prisma schema files.
 */
export interface SchemasContainer {
    /**
     * List of schema files.
     */
    files: SchemaContainer[];
}

/**
 * A container that holds the path and the content of a Prisma schema file.
 */
export interface SchemaContainer {
    /**
     * The content of the Prisma schema file.
     */
    content: string;
    /**
     * The file name of the Prisma schema file.
     */
    path: string;
}

/**
 * An object with a `url` field.
 * @deprecated
 */
export interface UrlContainer {
    /**
     * The URL string.
     */
    url: string;
}

/**
 * A list of migration directories with related information.
 */
export interface MigrationList {
    /**
     * Absolute path to the base directory of Prisma migrations.
     * E.g., `/usr/src/app/prisma/migrations`.
     */
    baseDir: string;
    /**
     * Description of the lockfile, which may or may not exist.
     */
    lockfile: MigrationLockfile;
    /**
     * An init script that will be run on the shadow database before the migrations are applied. Can be a no-op.
     */
    shadowDbInitScript: string;
    /**
     * List of migration directories.
     */
    migrationDirectories: MigrationDirectory[];
}

/**
 * Information about a migration lockfile.
 */
export interface MigrationLockfile {
    /**
     * Relative path to the lockfile from base directory.
     * E.g., `./migration_lock.toml`.
     */
    path: string;
    /**
     * Content of the lockfile, if it exists.
     */
    content: string | null;
}

/**
 * Information about a migration directory.
 */
export interface MigrationDirectory {
    /**
     * Relative path to a migration directory from `baseDir`.
     * E.g., `20201117144659_test`.
     */
    path: string;
    /**
     * Information about the migration file within the directory.
     */
    migrationFile: MigrationFile;
}

/**
 * Information about a migration file within a migration directory.
 */
export interface MigrationFile {
    /**
     * Relative path to the migration file from the migration directory.
     * E.g., `migration.sql`.
     */
    path: string;
    /**
     * Content of the migration file or error if it couldn\'t be read.
     */
    content: JsResult<string, string>;
}

export type JsResult<R, E> = { tag: "ok"; value: R } | { tag: "error"; value: E };

/**
 * The main query engine used by JS
 */
export class SchemaEngine {
  private constructor();
  free(): void;
  static new(options: ConstructorOptions, callback: Function, adapter: object): Promise<SchemaEngine>;
  /**
   * Debugging method that only panics, for tests.
   */
  debugPanic(): void;
  /**
   * Return the database version as a string.
   */
  version(_params?: GetDatabaseVersionInput | null): Promise<string>;
  /**
   * Apply all the unapplied migrations from the migrations folder.
   */
  applyMigrations(input: ApplyMigrationsInput): Promise<ApplyMigrationsOutput>;
  /**
   * Generate a new migration, based on the provided schema and existing migrations history.
   */
  createMigration(input: CreateMigrationInput): Promise<CreateMigrationOutput>;
  /**
   * Send a raw command to the database.
   */
  dbExecute(params: DbExecuteParams): Promise<void>;
  /**
   * Tells the CLI what to do in `migrate dev`.
   */
  devDiagnostic(input: DevDiagnosticInput): Promise<DevDiagnosticOutput>;
  /**
   * Create a migration between any two sources of database schemas.
   */
  diff(params: DiffParams): Promise<DiffResult>;
  /**
   * Looks at the migrations folder and the database, and returns a bunch of useful information.
   */
  diagnoseMigrationHistory(input: DiagnoseMigrationHistoryInput): Promise<DiagnoseMigrationHistoryOutput>;
  /**
   * Make sure the connection to the database is established and valid.
   * Connectors can choose to connect lazily, but this method should force
   * them to connect.
   */
  ensureConnectionValidity(_params: EnsureConnectionValidityParams): Promise<EnsureConnectionValidityResult>;
  /**
   * Evaluate the consequences of running the next migration we would generate, given the current state of a Prisma schema.
   */
  evaluateDataLoss(input: EvaluateDataLossInput): Promise<EvaluateDataLossOutput>;
  /**
   * Introspect the database schema.
   */
  introspect(params: IntrospectParams): Promise<IntrospectResult>;
  /**
   * Introspects a SQL query and returns types information.
   * Note: this will fail on SQLite, as it requires Wasm-compatible sqlx implementation.
   */
  introspectSql(params: IntrospectSqlParams): Promise<IntrospectSqlResult>;
  /**
   * Mark a migration from the migrations folder as applied, without actually applying it.
   */
  markMigrationApplied(input: MarkMigrationAppliedInput): Promise<MarkMigrationAppliedOutput>;
  /**
   * Mark a migration as rolled back.
   */
  markMigrationRolledBack(input: MarkMigrationRolledBackInput): Promise<MarkMigrationRolledBackOutput>;
  /**
   * Reset a database to an empty state (no data, no schema).
   */
  reset(input: ResetInput): Promise<void>;
  /**
   * The command behind `prisma db push`.
   */
  schemaPush(input: SchemaPushInput): Promise<SchemaPushOutput>;
}
